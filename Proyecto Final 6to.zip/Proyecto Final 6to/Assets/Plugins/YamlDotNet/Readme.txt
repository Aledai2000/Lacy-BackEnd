This is a port of the YamlDotNet library for Unity.

It has been tested and works with .net 2.0 subset, AOT compilation and even IL2CPP.
Platforms that have been tested includes PS Vita, Android, IOS and Desktop.

Please read the example code for a quick introduction to the YamlDotNet library.

If you get into trouble, you can browse the web for YamlDotNet information,
or you could send me an email ( post@fredrik.ludvigsen.name ).
