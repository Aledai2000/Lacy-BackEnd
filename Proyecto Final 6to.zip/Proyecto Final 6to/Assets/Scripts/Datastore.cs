﻿using UnityEngine;
using System.Collections.Generic;
using System.Text.RegularExpressions;

public abstract class Datastore<R, T> where T : Datastore<R, T> {
	private static Dictionary<R, T> _items = new Dictionary<R, T> ();

	public static T Find(R id){
		return _items [id];
	}

	public static void AddItems(List<T> items){
		foreach (T item in items) {
			AddItem(item);
		}
	}

	public static void AddItem(T item){
		string idName = Regex.Replace (item.nombre, @"\s+", "");
		R id = (R)System.Enum.Parse (typeof(R), idName, true);
		_items [id] = item;
		item.id = id;
	}

	public static void Clear(){
		_items.Clear ();
	}

	public R id { get; set; }
	public string nombre { get; set; }
	public string descripcion { get; set; }
	public Datastore(){
	}
		
}
