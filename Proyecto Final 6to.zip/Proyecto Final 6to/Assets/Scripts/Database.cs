﻿using UnityEngine;
using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using YamlDotNet.Serialization;
using YamlDotNet.Serialization.NamingConventions;
using YamlDotNet.RepresentationModel;
using YamlDotNet.Samples.Helpers;

//Este código sirve para cargar los archivos de Yaml en Unity
public class Database : MonoBehaviour{
	public class LoadingAYamlStream {
		public void Start(){
			LoadClasses ();
			Debug.Log ("Cargado correctamente!!");
		}

		//public class ClassList{
			//public List<Class> classes { get; set; }
		//}

	//public Database(){
	//}


		private readonly ITestOutputHelper output;
		public LoadingAYamlStream(ITestOutputHelper output) {
			this.output = output;
		}
		public void LoadClasses(){
			//TextAsset dialogosYaml = Resources.Load ("Dialogos") as TextAsset;
			var input = new StringReader (Dialogos);
			//Antes era así --> Stringreader input = new StringReader (objetosYaml.text);
			var yaml = new YamlStream ();
			yaml.Load (input);
			var mapping = (YamlMappingNode)yaml.Documents [0].RootNode;
			//Deserializer deserializer = new Deserializer (namingConvention: new CamelCaseNamingConvention ());
			//ClassList classList = deserializer.Deserialize<ClassList> (input);

			foreach (var entry in mapping.Children) {
				output.WriteLine (((YamlScalarNode)entry.Key).Value);
			}

			var dialogos = (YamlSequenceNode)mapping.Children [new YamlScalarNode ("dialogos")];
			foreach (YamlMappingNode dialogo in dialogos) {
				output.WriteLine (
					"{0}\t{1}",
					dialogo.Children [new YamlScalarNode ("id")],
					dialogo.Children [new YamlScalarNode ("contenido")]
				);
			}
		}
	private const string Dialogos = @"---
		dialogos:
  			- id: Personaje1
    		contenido: Hola, ¿Cómo estás?

  			- id: Personaje2
    		contenido: Todo bien y vos?

  			- id: Personaje1
    		contenido: Todo en orden y me alegro mucho de que estés bien.
...";
	}
}