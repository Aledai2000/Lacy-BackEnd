﻿using UnityEngine;
using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using YamlDotNet.Serialization;
using YamlDotNet.Serialization.NamingConventions;

//Este código sirve para cargar los archivos de Yaml en Unity
 
public class Database : MonoBehaviour {

	public void Start(){
		LoadClasses ();
		Debug.Log ("Cargado correctamente!!");
	}

	public class ClassList{
		public List<Class> classes { get; set; }

	}

	public Database(){
	}
		
	private void LoadClasses(){
		TextAsset objetosYaml = Resources.Load ("Objetos") as TextAsset;
		StringReader input1 = new StringReader (objetosYaml.text);
		TextAsset llavesYaml = Resources.Load ("Llaves") as TextAsset;
		StringReader input2 = new StringReader (llavesYaml.text);
		Deserializer deserializer1 = new Deserializer(namingConvention: new CamelCaseNamingConvention());
		ClassList classList1 = deserializer1.Deserialize<ClassList> (input1);
		Deserializer deserializer2 = new Deserializer(namingConvention: new CamelCaseNamingConvention());
		ClassList classList2 = deserializer2.Deserialize<ClassList> (input2);
	}
}
